const products = [
  { name: "Shirt", category: "cloth" },
  { name: "Pants", category: "cloth" },
  { name: "Rice 1kg", category: "grocery" },
  { name: "Sugar 1kg", category: "grocery" },
  { name: "PUBG UC", category: "game" },
  { name: "Free Fire Diamonds", category: "game" }
];

let cart = [];

function showProducts(list) {
  const box = document.getElementById("productList");
  box.innerHTML = "";
  list.forEach(p => {
    box.innerHTML += `
      <div class="product">
        <h3>${p.name}</h3>
        <button onclick="addToCart('${p.name}')">Add to Cart</button>
      </div>
    `;
  });
}

function filterCategory(cat) {
  if (cat === "all") showProducts(products);
  else showProducts(products.filter(p => p.category === cat));
}

function addToCart(item) {
  cart.push(item);
  showCart();
}

function showCart() {
  const box = document.getElementById("cartItems");
  box.innerHTML = cart.map(c => `<p>${c}</p>`).join("");
}

function openPayment() {
  alert("Redirecting to Razorpay demo payment...");
}

document.getElementById("searchBar").addEventListener("input", e => {
  const q = e.target.value.toLowerCase();
  const filtered = products.filter(p => p.name.toLowerCase().includes(q));
  showProducts(filtered);
});

showProducts(products);